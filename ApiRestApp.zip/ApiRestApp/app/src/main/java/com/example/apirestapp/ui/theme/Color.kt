package com.example.apirestapp

data class Color(
    val id: Int,
    val name: String,
    val hex: String
)